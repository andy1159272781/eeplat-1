import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import org.json.JSONException;

import com.exedosoft.plat.bo.BOInstance;

/**
 * 调用平台restful webservice
 * 
 * 平台的服务可以通过restful web service 的方式供外部访问。
restful web service 是一种轻量级的web service 的实现方式，简单而且高效。

1,"调用方"访问平台的服务，必须经过授权，需要平台提供的用户名和密码，"调用方"需要小心保护用户名密码，最好经常更换密码。

2，如果一个服务需要被外部访问那么必须设置服务的可见性，可见性为public 或 
public类型的服务:只要"调用方"取得平台提供的用户名密码即可访问。
protected类型的服务："调用方"除了取得平台提供的用户名密码即可访问，还要单独授权。

3，对"调用方"的验证方式是可以自定义的：
在globals.xml中：
    <property name="webservice.login.service">do_org_user_findbynameandpwd</property>
这个是验证"调用方"的用户名和密码，可以和普通用户登录的服务一样，这样"调用方"的用户名密码也存放在用户表中，从安全性角度讲，最好分开。
    <property name="webservice.auth.service">exists_rest</property>
这个验证proteced的服务是否获得单独授权。
4，restclient是用java 客户端访问平台服务的例子，是一个eclipse 工程，详见RestExample 类。

 * @author Administrator
 * 
 */

public class RestExample {

	
	public final static String baseCallUrl = "http://127.0.0.1:8080/yiyi/servicecontroller?greenChannel=true&userName=u&pwd=b59c67bf196a4758191e42f76670ceba";
	


	public static void main(String[] args) throws IOException {

		BOInstance bi = restZfService();
		System.out.println(Escape.unescape(bi.getValue("echo_msg")));

		// instance = restInsert();
		// System.out.println(instance);

	}

	/**
	 * 如果调用 平台的新增类型的服务
	 * 
	 * @return
	 * @throws IOException
	 */
	private static BOInstance restZfService() throws IOException {

		StringBuffer callZfService = new StringBuffer(baseCallUrl).append(
				"&callType=uf&contextServiceName=engine&").append("&message=")
				.append(URLEncoder.encode("test", "utf-8"));

		StringBuffer buffer = callRest(callZfService.toString());
		BOInstance instance = null;
		try {
			instance = BOInstance.fromJSONString(buffer.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return instance;
	}

	/**
	 * 如果调用 平台的新增类型的服务
	 * 
	 * @return
	 * @throws IOException
	 */
	private static BOInstance restInsert() throws IOException {

		StringBuffer callInsert = new StringBuffer(baseCallUrl).append(
				"&callType=us&contextServiceName=do_sms_insert&MESSAGETYPE=")
				.append(URLEncoder.encode("类型", "utf-8")).append("&MESSAGE=")
				.append(URLEncoder.encode("团结一心", "utf-8")).append(
						"&MESSAGETIME=2009-02-08");

		StringBuffer buffer = callRest(callInsert.toString());
		BOInstance instance = null;
		try {
			instance = BOInstance.fromJSONString(buffer.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return instance;
	}

	/**
	 * 如果调用 平台的查询类型的服务
	 * 
	 * @return
	 * @throws IOException
	 */
	private static BOInstance restSelect() throws IOException {

		String callSelect = baseCallUrl
				+ "&callType=sm&contextServiceName=do_sms_findbysmsid&objuid=1";

		StringBuffer buffer = callRest(callSelect);

		BOInstance instance = null;
		try {
			// /得到多条记录
			BOInstance allDatas = BOInstance.fromJSONString(buffer.toString());

			// //主键为1的记录
			instance = BOInstance.fromJSONString(allDatas.getValue("1"));

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return instance;
	}

	/**
	 * 调用 restful webservice
	 * 
	 * @param strUrl
	 * @return
	 * @throws IOException
	 */
	public static StringBuffer callRest(String strUrl) throws IOException {

		StringBuffer buffer = new StringBuffer();

		URL url = new URL(strUrl);
		URLConnection uc = url.openConnection();
		uc.setReadTimeout(1000 * 30);

		InputStream is = uc.getInputStream();

		String line = "";
		BufferedReader in = new BufferedReader(new InputStreamReader(is,
				"utf-8"));
		while ((line = in.readLine()) != null) {
			buffer.append(line).append("\n");
		}

		is.close();

		return buffer;

	}

}
